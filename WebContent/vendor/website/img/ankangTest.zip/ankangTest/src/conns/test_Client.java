package conns;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.net.UnknownHostException;

import org.dom4j.DocumentException;

public class test_Client {

	/**
	 * @param args
	 * @throws IOException 
	 * @throws UnknownHostException 
	 * @throws DocumentException 
	 */
	public static void main(String[] args) throws UnknownHostException, IOException, DocumentException {
		// TODO Auto-generated method stub
		//创建客户端对象，指定IP/端口
		Socket c=new Socket("localhost",8888);
		//获取客户端输出流
		OutputStream out =	c.getOutputStream();
		
		out.write("getallmess".getBytes());
		//将流置于末尾
		c.shutdownOutput();
		out.flush();
		byte []b=new byte[1024];
		int sum=0;
		String str1="";
		//获取客户端输入流
		InputStream in=	c.getInputStream();
		while((sum=in.read(b))!=-1)
		{
			String str=new String(b,0,sum);
			str1+=str;
			
		}
		System.out.println("服务端说"+str1);
		method m=new method();
		m.passXMl(str1);
		
		
		
	}

}
