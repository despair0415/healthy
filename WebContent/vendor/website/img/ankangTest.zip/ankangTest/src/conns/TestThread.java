package conns;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;


public class TestThread extends Thread {
	Socket c;
	public TestThread(Socket c)
	{
		this.c=c;
		
		
	}
	//线程体
	public void run()
	{
		try {
			
			//可能出现高并发的代码段
			byte []b=new byte[1024];
			int sum=0;
			String str1="";
			//获取客户端输入流
			InputStream in=	c.getInputStream();
			//获取客户端输出流
			OutputStream out=c.getOutputStream();
			while((sum=in.read(b))!=-1)
			{
				String str=new String(b,0,sum);
				str1+=str;
				
			}
			System.out.println("客户端说"+str1);
			if(str1.equals("getallmess"))
			{
				method m=new method();
				String xml=m.createXMl();
				out.write(xml.getBytes());
				//关流
				out.flush();
				out.close();
				in.close();
				
				
			}
			
			
			
			
			
			
			
			
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		
	}

}
