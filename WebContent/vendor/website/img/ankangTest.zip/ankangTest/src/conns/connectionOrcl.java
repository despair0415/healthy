package conns;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class connectionOrcl {


Connection  con= null;
Statement sta=null;
ResultSet res=null;
//打开数据库连接
	public boolean openOrcl()
	{
			boolean re=false;
		try {
			
			//加载驱动
			Class.forName("oracle.jdbc.driver.OracleDriver");
			//注册驱动
	        DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
	      //连接数据库
	        String url="jdbc:oracle:thin:@localhost:1521:XE" ;
	        String UserName="system";
	        String UserPass="123456";
	          con=  DriverManager.getConnection(url,UserName,UserPass);
			if(con==null)
			{
				
				//no
				
			}else
			{
				re=true;
				//ok
			}
			
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return re;
	}
	 //增删改
	/**
	 * @author kissli
	 * Time:2020-12-22
	 * 功能：增删改数据
	 * Tel:15821731090
	 * 
	 */
public int update(String sql)
{
	int re=0;
	try {
		sta=con.createStatement();
		re=sta.executeUpdate(sql);
		
	} catch (Exception e) {
		// TODO: handle exception
	}
	return re;
	
 
}
	//查询方法
public ResultSet select(String sql)
{
  try {
		sta=con.createStatement();
		res=   sta.executeQuery(sql);
} catch (Exception e) {
	// TODO: handle exception
}
return res;
}
	
	
//关闭连接
public void closeOrcl()
{
	try {
		
		res.close();
		sta.close();
		con.close();//慎重
	} catch (Exception e) {
		// TODO: handle exception
	}
	
	

}
	
	
public static void main(String[] args) {
	connectionOrcl con =new connectionOrcl();
	con.openOrcl();
	int re=con.update("insert into ankangUser values(ankang.nextval,'sss','123')");
	System.out.println(re);
}	
	
	
	
}
