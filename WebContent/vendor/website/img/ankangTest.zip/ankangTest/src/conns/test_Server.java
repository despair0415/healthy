package conns;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

public class test_Server {

	/**
	 * @param args
	 * @throws IOException 
	 */
	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		//创建服务端对象,打开端口
		ServerSocket s=new ServerSocket(8888);
		for(;;)
		{
			//监听端口
			System.out.println("服务器已启动");
			Socket c=s.accept();
			//创建线程
			TestThread t=new TestThread(c);
			t.start();
			
		}
	

	}

}
