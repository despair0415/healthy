package conns;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;

public class method {
//查看表信息
	public void showtableMessage( String tableName) throws SQLException
	{
		 connectionOrcl con=new connectionOrcl();
	     con.openOrcl();
	     String sql="select * from "+tableName+"";
	     ResultSet res=   con.select(sql);
	     
	     ResultSetMetaData mata =res.getMetaData();
	     //获取对应表字段个数
			int sum =mata.getColumnCount();
			System.out.println(sum);
			for(int i=1;i<=sum;i++)
			{
				System.out.println(mata.getColumnName(i)+":"+mata.getColumnTypeName(i));

			}

	}
	//动态创建xml协议
	public String createXMl() throws SQLException
	{
		//创建xml文档
		Document document=	DocumentHelper.createDocument();
		//创建节点
		 Element xml=	DocumentHelper.createElement("xml");
		connectionOrcl con=new connectionOrcl();
		con.openOrcl();
		ResultSet res=	con.select("select * from ankangstudent001");
		//设置根节点
		document.setRootElement(xml);
		while(res.next())
		{
			 Element student=	DocumentHelper.createElement("student");
			 Element stuid=	DocumentHelper.createElement("stuid");
			 stuid.setText(String.valueOf(res.getInt("stuid")));
			 Element stuname=	DocumentHelper.createElement("stuname");
			 stuname.setText(res.getString("stuname"));
			 Element stusex=	DocumentHelper.createElement("stusex");
			 stusex.setText(res.getString("stusex"));
			 Element stuage=	DocumentHelper.createElement("stuage");
			 stuage.setText(String.valueOf(res.getInt("stuage")));
			 Element stutem=	DocumentHelper.createElement("stutem");
			 stutem.setText(String.valueOf(res.getInt("stutem")));
			 xml.add(student);
			 student.add(stuid);
			 student.add(stuname);
			 student.add(stusex);
			 student.add(stuage);
			 student.add(stutem);

			
		}
		//将xml文档转为字符串
		return	document.asXML();
		 
	}
	
	//XMl协议解析方法
	public void passXMl(String xml) throws DocumentException
	{
		//将字符串转为xml文档
		Document document=DocumentHelper.parseText(xml);
		List list=document.selectNodes("xml/student");
		for(int i=0;i<list.size();i++){
			
		Element stu=(Element)list.get(i);
		String stuid=	stu.selectSingleNode("stuid").getText();
		String stuname=	stu.selectSingleNode("stuname").getText();
		String stusex=	stu.selectSingleNode("stusex").getText();
		String stuage=	stu.selectSingleNode("stuage").getText();
		String stutem=	stu.selectSingleNode("stutem").getText();
		System.out.println(stuid+":"+stuname+":"+stusex+":"+stuage+":"+stutem);
			
		}
		
		
		
	}
	
	
	
	
	//用户注册
	public int insertUser(String name,String pass) throws ClassNotFoundException, SQLException{
		int re=0;
		connectionOrcl con=new connectionOrcl();
		con.openOrcl();
		ResultSet res=	con.select("select upass from ankangUser where uname='"+name+"'");
	
	    if(res.next())
	    {
	    	
	      re=2;//用户已存在
	    	
	    }else
	    {
	    	String sql="insert into ankangUser values(ankang.nextval,'"+name+"','"+pass+"')";
		   re= con.update(sql);	
	    	System.out.println(sql+"kkkk");
	    	
	    }
		
		return re;
		
	}
	//用户登录
	public int getLogin(String name,String pass) throws ClassNotFoundException, SQLException
	{
		int re=0;
		connectionOrcl con=new connectionOrcl();
		con.openOrcl();
		String upass="";
		ResultSet res=con.select("select upass from ankangUser where uname='"+name+"'");
		while(res.next())
		{
			upass=res.getString("upass");
		}
		if(upass.equals(pass))
		{
			re=1;
		}else if(upass.equals(""))
		{
			re=2;
		}else
		{
			re=3;
		}
		return re;
	}
	
	
	
	public static void main(String[] args) throws SQLException {
		method m=new method();
		System.out.println(m.createXMl());
	}
	
	
	
	

}
