package conns;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class test {

	/**
	 * @param args
	 * @throws SQLException 
	 */
	public static void main(String[] args) throws SQLException {

		method m=new method();
		m.showtableMessage("student");
		
		
		
		
		
		
		
		//		// TODO Auto-generated method stub
//     connectionOrcl con=new connectionOrcl();
//     //
//     con.openOrcl();
//     
//     
     
     
     
     
//    // String sql="insert into ankangstudent001 values(2,'狗剩','男',18,36)";
//     //con.update(sql);
//     //查询
//     String sql="select * from ankangstudent001";
//     ResultSet res=   con.select(sql);
////	 while(res.next())
////	 {
////		System.out.print( res.getInt("stuid"));
////		System.out.print(res.getString("stuname")); 
////		System.out.print(res.getString("stusex")); 
////		System.out.println( res.getInt("stuage"));
////		 
////	 }
//     
//     //查看表源数据
//     
//     ResultSetMetaData mata =res.getMetaData();
//     //获取对应表字段个数
//		int sum =mata.getColumnCount();
//		System.out.println(sum);
//		for(int i=1;i<=sum;i++)
//		{
//			System.out.println(mata.getColumnName(i)+":"+mata.getColumnTypeName(i));
//
//			
//			
//		}
//		
//		
//		
	}

}
